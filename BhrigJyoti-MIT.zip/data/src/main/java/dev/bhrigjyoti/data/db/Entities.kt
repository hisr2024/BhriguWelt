package dev.bhrigjyoti.data.db
import androidx.room.*
@Entity(tableName = "readings")
data class ReadingEntity(@PrimaryKey val id: String, val createdAt: Long, val name: String?,
  val birthIso: String, val lat: Double, val lon: Double, val zoneId: String, val snapshotJson: String, val outputsJson: String)
