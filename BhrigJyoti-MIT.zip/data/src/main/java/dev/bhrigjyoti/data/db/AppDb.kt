package dev.bhrigjyoti.data.db
import androidx.room.Database
import androidx.room.RoomDatabase
@Database(entities = [ReadingEntity::class], version = 1)
abstract class AppDb: RoomDatabase() { abstract fun reading(): ReadingDao }
