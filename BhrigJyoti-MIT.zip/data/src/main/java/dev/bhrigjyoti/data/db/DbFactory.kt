package dev.bhrigjyoti.data.db
import android.content.Context
import androidx.room.Room
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import dev.bhrigjyoti.data.secure.DbKeyStore
object DbFactory {
  fun create(ctx: Context): AppDb {
    SQLiteDatabase.loadLibs(ctx)
    val key = DbKeyStore.getOrCreate(ctx)
    val factory = SupportFactory(key)
    return Room.databaseBuilder(ctx, AppDb::class.java, "bhrigu.db")
      .openHelperFactory(factory)
      .fallbackToDestructiveMigration()
      .build()
  }
}
