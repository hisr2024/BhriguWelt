package dev.bhrigjyoti.data.secure
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
object DbKeyStore {
  private const val PREF="secure_prefs"; private const val KEY_MATERIAL="db_key_material"
  fun getOrCreate(ctx: Context): ByteArray {
    val spec = MasterKeys.AES256_GCM_SPEC
    val masterKey = MasterKeys.getOrCreate(spec)
    val prefs = EncryptedSharedPreferences.create(PREF, masterKey, ctx,
      EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
      EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    val hex = prefs.getString(KEY_MATERIAL, null)
    if (hex != null) {
      return try { hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray() } catch (e: Exception) {
        // fallthrough to create
        ByteArray(0)
      }.takeIf { it.isNotEmpty() } ?: run { /* create new */ val fresh = java.util.UUID.randomUUID().toString().replace("-", "") }
    }
    val fresh = ByteArray(32) { (0..255).random().toByte() }
    prefs.edit().putString(KEY_MATERIAL, fresh.joinToString("") { b -> "%02x".format(b) }).apply()
    return fresh
  }
}
