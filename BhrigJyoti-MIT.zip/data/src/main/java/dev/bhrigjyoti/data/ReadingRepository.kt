package dev.bhrigjyoti.data
import android.content.Context
import dev.bhrigjyoti.core.model.*
import dev.bhrigjyoti.engine.*
import dev.bhrigjyoti.bhrigu.*
import dev.bhrigjyoti.data.db.*
import kotlinx.serialization.json.Json
import java.util.UUID
class ReadingRepository(ctx: Context, private val eph: Ephemeris = DemoEphemeris()) {
  private val db = DbFactory.create(ctx)
  private val calc = Calculator(eph)
  private val rules = listOf(
    Rule("DEMO-CHAR-AR", MatchSpec(lagnas = listOf(Rashi.AR)), category = "Overview", english = "Direct, initiating temperament; channel energy wisely."),
    Rule("DEMO-PL-PUSHYA", MatchSpec(moonNakshatra = Nakshatra.PUSHYA), category = "Past Life", english = "A caretaking motif echoes from the past.", remedies = listOf("Support elders on Mondays")),
    Rule("DEMO-FUT-01", MatchSpec(), category = "Future", english = "Constructive opportunities likely in the next cycle.", remedies = listOf("Plan, pace, and rest"))
  )
  private val engine = RuleEngine(rules)
  private val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }
  suspend fun generateAndSave(data: BirthData): String {
    val (chart, outs) = generateReading(data)
    val id = UUID.randomUUID().toString()
    val e = ReadingEntity(id, System.currentTimeMillis(), data.name, data.datetime.toString(), data.latitude, data.longitude, data.zoneId,
      json.encodeToString(ChartSnapshot.serializer(), chart),
      json.encodeToString(kotlinx.serialization.builtins.ListSerializer(BhriguText.serializer()), outs))
    db.reading().upsert(e); return id
  }
  fun observeAll() = db.reading().all()
  suspend fun load(id: String) = db.reading().byId(id)
  fun generateReading(data: BirthData): Pair<ChartSnapshot, List<BhriguText>> { val c = calc.computeChart(data); return c to engine.evaluate(c) }
}
