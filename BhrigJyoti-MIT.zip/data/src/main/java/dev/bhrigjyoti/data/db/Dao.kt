package dev.bhrigjyoti.data.db
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface ReadingDao {
  @Query("SELECT * FROM readings ORDER BY createdAt DESC") fun all(): Flow<List<ReadingEntity>>
  @Query("SELECT * FROM readings WHERE id = :id") suspend fun byId(id: String): ReadingEntity?
  @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: ReadingEntity)
  @Query("DELETE FROM readings WHERE id = :id") suspend fun delete(id: String)
}
