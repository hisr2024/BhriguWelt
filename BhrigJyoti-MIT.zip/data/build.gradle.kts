plugins { id("com.android.library"); kotlin("android"); kotlin("kapt") }
android { namespace = "dev.bhrigjyoti.data"; compileSdk = 35; defaultConfig { minSdk = 26 } }
dependencies {
  implementation(project(":core")); implementation(project(":engine-bhrigu")); implementation(project(":engine-jyotisha"))
  implementation(libs.room.ktx); kapt(libs.room.compiler)
  implementation(libs.serialization.json)
  implementation(libs.security.crypto)
  implementation(libs.sqlcipher)
}
