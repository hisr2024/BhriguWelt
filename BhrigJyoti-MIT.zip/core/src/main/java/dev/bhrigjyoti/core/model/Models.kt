package dev.bhrigjyoti.core.model

import kotlinx.serialization.Serializable
import java.time.LocalDateTime

@Serializable data class BirthData(
  val name: String? = null,
  val datetime: LocalDateTime,
  val zoneId: String,
  val latitude: Double,
  val longitude: Double
)
enum class CelestialBody { SUN, MOON, MARS, MERCURY, JUPITER, VENUS, SATURN, RAHU, KETU, LAGNA }
enum class Rashi { AR, TA, GE, CN, LE, VI, LI, SC, SG, CP, AQ, PI }
enum class Nakshatra { ASHWINI, BHARANI, KRITTIKA, ROHINI, MRIGASHIRA, ARDRA, PUNARVASU, PUSHYA, ASLESHA,
  MAGHA, PURVA_PHALGUNI, UTTARA_PHALGUNI, HASTA, CHITRA, SWATI, VISHAKHA, ANURADHA, JYESHTHA, MULA,
  PURVA_ASHADHA, UTTARA_ASHADHA, SHRAVANA, DHANISHTA, SHATABHISHA, PURVA_BHADRAPADA, UTTARA_BHADRAPADA, REVATI }
@Serializable data class Panchanga(val tithi: Int, val nakshatra: Nakshatra, val yoga: Int, val karana: Int, val vara: Int)
@Serializable data class ZodiacDegree(val degrees: Double)
@Serializable data class PlanetPosition(
  val body: CelestialBody, val geoLongitude: Double, val speed: Double,
  val sign: Rashi, val nakshatra: Nakshatra, val pada: Int, val house: Int
)
@Serializable data class ChartSnapshot(
  val julianDay: Double,
  val planets: List<PlanetPosition>,
  val ascendant: ZodiacDegree,
  val houses: List<ZodiacDegree>,
  val ayanamsha: Double,
  val panchanga: Panchanga
)
