plugins { id("com.android.library"); kotlin("android") }
android { namespace = "dev.bhrigjyoti.core"; compileSdk = 35; defaultConfig { minSdk = 26 } }
dependencies { implementation(libs.serialization.json) }
