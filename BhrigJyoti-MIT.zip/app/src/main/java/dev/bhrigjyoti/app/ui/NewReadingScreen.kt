package dev.bhrigjyoti.app.ui
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.bhrigjyoti.core.model.BirthData
import dev.bhrigjyoti.data.ReadingRepository
import java.time.LocalDateTime
import java.time.ZoneId
import kotlinx.coroutines.launch

@Composable
fun NewReadingScreen(repo: ReadingRepository, onSaved:(String)->Unit) {
  var name by remember { mutableStateOf("") }
  var city by remember { mutableStateOf("") }
  var lat by remember { mutableStateOf(28.6139) }
  var lon by remember { mutableStateOf(77.2090) }
  var zone by remember { mutableStateOf(ZoneId.systemDefault().id) }
  val scope = rememberCoroutineScope()

  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text("New Reading", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier=Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City (optional)") }, modifier=Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    Row { Button(onClick={ zone = ZoneId.systemDefault().id }) { Text("Use my timezone") }; Spacer(Modifier.width(8.dp)); Text(zone) }
    Spacer(Modifier.height(12.dp))
    Button(onClick = {
      scope.launch {
        val id = repo.generateAndSave(BirthData(name.ifBlank{null}, LocalDateTime.now(), zone, lat, lon))
        onSaved(id)
      }
    }) { Text("Generate & Save") }
  }
}
