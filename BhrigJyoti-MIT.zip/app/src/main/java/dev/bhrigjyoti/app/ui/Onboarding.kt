package dev.bhrigjyoti.app.ui
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun Onboarding(onDone:()->Unit) {
  var step by remember { mutableStateOf(0) }
  val steps = listOf("Language", "Mode", "Sensitivity")
  Scaffold(topBar={ TopAppBar(title={ Text("Welcome") }) }) { pad ->
    Column(Modifier.padding(pad).padding(16.dp)) {
      Text("Step ${step+1}/${steps.size}: ${steps[step]}")
      Spacer(Modifier.height(12.dp))
      when(step){
        0 -> { Text("Choose language (English/Hindi). (placeholder)") }
        1 -> { Text("Simple mode shows plain language; Expert shows full details.") }
        2 -> { Text("Sensitive topics hidden by default; you can enable later.") }
      }
      Spacer(Modifier.height(12.dp))
      Row {
        if (step>0) Button(onClick={step-=1}, modifier=Modifier.padding(end=8.dp)) { Text("Back") }
        if (step<steps.size-1) Button(onClick={step+=1}){ Text("Next") } else Button(onClick=onDone){ Text("Finish") }
      }
    }
  }
}
