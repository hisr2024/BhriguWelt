package dev.bhrigjyoti.app.ui
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.bhrigjyoti.data.ReadingRepository
import kotlinx.coroutines.flow.collectLatest

@Composable
fun HistoryScreen(repo: ReadingRepository) {
  val list = remember { mutableStateListOf<dev.bhrigjyoti.data.db.ReadingEntity>() }
  LaunchedEffect(Unit) { repo.observeAll().collectLatest { list.clear(); list.addAll(it) } }
  LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
    items(list.size) { idx ->
      val e = list[idx]
      Card(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
        Column(Modifier.padding(12.dp)) {
          Text(e.name ?: "Unnamed", style = MaterialTheme.typography.titleMedium)
          Text(e.birthIso, style = MaterialTheme.typography.bodySmall)
        }
      }
    }
  }
}
