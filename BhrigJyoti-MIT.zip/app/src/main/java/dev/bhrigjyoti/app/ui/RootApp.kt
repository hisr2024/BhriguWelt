package dev.bhrigjyoti.app.ui
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.bhrigjyoti.data.ReadingRepository

enum class Tab { New, History, Settings }

@Composable
fun RootApp(repo: ReadingRepository) {
  var showOnboarding by remember { mutableStateOf(true) }
  var tab by remember { mutableStateOf(Tab.New) }
  MaterialTheme {
    if (showOnboarding) {
      Onboarding(onDone = { showOnboarding = false })
    } else {
      Scaffold(
        bottomBar = {
          Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick={tab=Tab.New}) { Text("New") }
            Button(onClick={tab=Tab.History}) { Text("History") }
            Button(onClick={tab=Tab.Settings}) { Text("Settings") }
          }
        }
      ) { pad ->
        Box(Modifier.padding(pad)) {
          when(tab){
            Tab.New -> NewReadingScreen(repo){}
            Tab.History -> HistoryScreen(repo)
            Tab.Settings -> SettingsScreenSimple()
          }
        }
      }
    }
  }
}
