package dev.bhrigjyoti.app.ui
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreenSimple() {
  Column(Modifier.fillMaxSize().padding(16.dp)) {
    Text("Settings", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("Language: English (placeholder)")
    Text("Script: IAST (placeholder)")
    Text("Sensitive content: Hidden (default)")
    Text("Security: Encrypted DB (SQLCipher), No screenshots")
  }
}
