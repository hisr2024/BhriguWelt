plugins { id("com.android.application"); kotlin("android") }
android {
  namespace = "dev.bhrigjyoti.app"; compileSdk = 35
  defaultConfig { applicationId = "dev.bhrigjyoti.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
  buildFeatures { compose = true }
  composeOptions { kotlinCompilerExtensionVersion = libs.versions.compose.get() }
  buildTypes {
    getByName("release") {
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }
}
dependencies {
  implementation(project(":core")); implementation(project(":engine-jyotisha")); implementation(project(":engine-bhrigu")); implementation(project(":data"))
  implementation(libs.core.ktx); implementation(libs.activity.compose); implementation(libs.compose.ui); implementation(libs.compose.material3); implementation(libs.lifecycle.runtime); implementation(libs.lifecycle.viewmodel)
}
