package dev.bhrigjyoti.engine
import dev.bhrigjyoti.core.model.*
import java.time.LocalDateTime
enum class Ayanamsha { LAHIRI, KRISHNAMURTI, RAMAN }
interface Ephemeris {
  fun toJulianDay(local: LocalDateTime, zoneId: String): Double
  fun ayanamsha(jd: Double, type: Ayanamsha): Double
  fun eclipticLongitude(body: CelestialBody, jd: Double): Double
  fun speed(body: CelestialBody, jd: Double): Double
  fun ascendant(lat: Double, lon: Double, jd: Double, ayanamsha: Double): ZodiacDegree
  fun panchanga(jd: Double, ayanamsha: Double): Panchanga
}
