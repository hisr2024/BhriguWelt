package dev.bhrigjyoti.engine
import dev.bhrigjyoti.core.model.*
class Calculator(private val eph: Ephemeris) {
  fun computeChart(data: BirthData, ayanamshaType: Ayanamsha = Ayanamsha.LAHIRI): ChartSnapshot {
    val jd = eph.toJulianDay(data.datetime, data.zoneId)
    val aya = eph.ayanamsha(jd, ayanamshaType)
    val planets = CelestialBody.values().filter { it != CelestialBody.LAGNA }.map { b ->
      val sid = ((eph.eclipticLongitude(b, jd) - aya).mod(360.0) + 360.0) % 360.0
      val sign = Rashi.values()[(sid/30).toInt()]
      val nak = Nakshatra.values()[(sid/(360.0/27)).toInt()]
      val pada = ((sid % (360.0/27)) / (360.0/108)).toInt() + 1
      PlanetPosition(b, sid, eph.speed(b, jd), sign, nak, pada, 1)
    }
    val lagna = eph.ascendant(data.latitude, data.longitude, jd, aya)
    val houses = (0 until 12).map { ZodiacDegree((lagna.degrees + it*30) % 360) }
    val panchanga = eph.panchanga(jd, aya)
    val withHouses = planets.map { it.copy(house = (((it.geoLongitude - lagna.degrees + 360)%360)/30).toInt() + 1) }
    return ChartSnapshot(jd, withHouses, lagna, houses, aya, panchanga)
  }
}
