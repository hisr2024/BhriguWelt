package dev.bhrigjyoti.engine
import dev.bhrigjyoti.core.model.*
import java.time.*
class DemoEphemeris: Ephemeris {
  override fun toJulianDay(local: LocalDateTime, zoneId: String): Double {
    val z = ZonedDateTime.of(local, ZoneId.of(zoneId))
    return z.toInstant().toEpochMilli() / 86400000.0 + 2440587.5
  }
  override fun ayanamsha(jd: Double, type: Ayanamsha) = 24.0
  override fun eclipticLongitude(body: CelestialBody, jd: Double) = when(body){
    CelestialBody.SUN->(jd%360); CelestialBody.MOON->(jd*13%360); CelestialBody.MARS->(jd*0.5%360);
    CelestialBody.MERCURY->(jd*1.2%360); CelestialBody.JUPITER->(jd*0.08%360); CelestialBody.VENUS->(jd*1.1%360);
    CelestialBody.SATURN->(jd*0.03%360); CelestialBody.RAHU->(jd* -0.05 %360); CelestialBody.KETU->(jd* -0.05 %360);
    CelestialBody.LAGNA->0.0 }
  override fun speed(body: CelestialBody, jd: Double) = 1.0
  override fun ascendant(lat: Double, lon: Double, jd: Double, ayanamsha: Double) = ZodiacDegree(((jd+lon)%360+360)%360)
  override fun panchanga(jd: Double, ayanamsha: Double) = Panchanga(((jd.toInt()%30)+1), Nakshatra.ASHWINI, 1, 1, 0)
}
