plugins { id("com.android.library"); kotlin("android") }
android { namespace = "dev.bhrigjyoti.engine"; compileSdk = 35; defaultConfig { minSdk = 26 } }
dependencies { implementation(project(":core")) }
