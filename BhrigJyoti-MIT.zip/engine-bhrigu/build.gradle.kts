plugins { id("com.android.library"); kotlin("android") }
android { namespace = "dev.bhrigjyoti.bhrigu"; compileSdk = 35; defaultConfig { minSdk = 26 } }
dependencies { implementation(project(":core")) }
