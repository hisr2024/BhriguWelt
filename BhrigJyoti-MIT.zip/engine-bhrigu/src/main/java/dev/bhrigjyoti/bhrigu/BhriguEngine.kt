package dev.bhrigjyoti.bhrigu
import dev.bhrigjyoti.core.model.*
@kotlinx.serialization.Serializable
data class BhriguText(val ruleId: String, val category: String, val title: String? = null,
  val sanskrit: String? = null, val english: String, val remedies: List<String> = emptyList())
@kotlinx.serialization.Serializable
data class MatchSpec(val lagnas: List<Rashi>? = null, val moonNakshatra: Nakshatra? = null)
@kotlinx.serialization.Serializable
data class Rule(val id: String, val match: MatchSpec, val category: String, val english: String, val remedies: List<String> = emptyList())
class RuleEngine(private val rules: List<Rule>) {
  fun evaluate(chart: ChartSnapshot): List<BhriguText> {
    val ascRashi = Rashi.values()[((chart.ascendant.degrees/30).toInt())]
    val moon = chart.planets.first { it.body == CelestialBody.MOON }
    return rules.filter { r -> (r.match.lagnas?.contains(ascRashi) ?: true) && (r.match.moonNakshatra?.equals(moon.nakshatra) ?: true) }
      .map { r -> BhriguText(r.id, r.category, english = r.english, remedies = r.remedies) }
  }
}
